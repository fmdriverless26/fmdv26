#!/usr/bin/env python3
"""
renderer_node.py

Full 3D synthetic camera for eufs_sim2: renders the REAL car mesh, REAL wheel
meshes (spinning, computed from /odom speed + wheel radius), REAL cone meshes
(borrowed from eufs_sim_v1, colored per class), with cones tipped over when
the collision tracker reports a hit. Rendered with pyrender (offscreen, EGL/
GPU) from the camera's mounted viewpoint, published as a live image topic.

ASSUMPTIONS TO VERIFY (defaults are reasonable FS guesses, not measured):
    - wheelbase_m, chassis_width_m: not found in your xacro yet (they're
      macro params set from elsewhere). Defaults below are typical ADS-DV
      values. Fix with --ros-args -p wheelbase_m:=<real> etc.
    - cam_mount_x/z: ZED's mount point on the chassis wasn't in the files we
      grepped. Defaults guess "near the front, roughly windshield height."
    - cone.dae is assumed to be the standard ORANGE cone (the only one of
      the 4 files without a color suffix, and it's the only class left
      unmatched: blue/yellow/big are all named explicitly).
    - Wheel spin direction sign is a best guess - flip `wheel_spin_sign` to
      -1 if wheels visually spin backwards.
    - Steering angle is NOT modeled (front wheels render straight always).
      Fine for drive_straight.py; extend later if you add real steering.
    - Cone "hit" matching assumes the same cone `id` is consistent between
      /camera/cones and /plugin/cone_collision_tracker/colliding_cones.

Subscribes:
    /camera/cones                                  (eufs_msgs/ConeWithColorProbabilityArray)
    /plugin/cone_collision_tracker/colliding_cones  (eufs_msgs/ConeWithColorProbabilityArray)
    /odom                                           (nav_msgs/Odometry)

Publishes:
    /rendered_camera/image_raw  (sensor_msgs/Image, bgr8)
"""

import os
os.environ.setdefault('PYOPENGL_PLATFORM', 'egl')  # must be set before importing pyrender

import math
import time
import numpy as np
import trimesh
import trimesh.transformations as tft
import pyrender

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo, PointCloud2, PointField
from nav_msgs.msg import Odometry
from eufs_msgs.msg import ConeWithColorProbabilityArray
from std_msgs.msg import Float32, Int32

MESH_DIR_CAR = os.path.expanduser(
    '~/modified_eufs_sim_v2/eufs_sim/eufs-master/src/eufs_sim2/eufs_racecar/car/meshes'
)
MESH_DIR_CONES = os.path.expanduser(
    '~/eufs_sim_v1/rough-work/modified_eufs_sim/eufs_tracks/meshes'
)

CONE_MESH_BY_COLOR = {
    'blue': os.path.join(MESH_DIR_CONES, 'cone_blue.dae'),
    'yellow': os.path.join(MESH_DIR_CONES, 'cone_yellow.dae'),
    'orange': os.path.join(MESH_DIR_CONES, 'cone.dae'),
    'big_orange': os.path.join(MESH_DIR_CONES, 'cone_big.dae'),
}

# World/body convention throughout this file: x=forward, y=left, z=up
# (matches base_footprint / ROS REP103). Camera basis conversion happens
# only once, in build_camera_pose().


def load_pyrender_mesh(path, scale=1.0):
    """
    Load a (possibly multi-geometry) COLLADA file and build a pyrender.Mesh,
    correctly applying each part's internal scene-graph transform.

    KEY FIX (found after extensive isolation testing): letting
    pyrender.Mesh.from_trimesh() auto-detect each part's material from
    trimesh's parsed visual data silently produces the wrong rendered color
    - even though the resulting Material object's own baseColorFactor
    attribute reads back correctly when inspected. Explicitly constructing
    each part's pyrender.MetallicRoughnessMaterial ourselves, and passing it
    in directly, renders correctly. So: never let pyrender auto-derive
    materials from a loaded trimesh - always build them explicitly.
    """
    loaded = trimesh.load(path, force='scene')
    if isinstance(loaded, trimesh.Scene):
        submeshes = loaded.dump(concatenate=False)
    else:
        submeshes = [loaded]
    if scale != 1.0:
        for m in submeshes:
            m.apply_scale(scale)

    primitives = []
    for m in submeshes:
        mat = getattr(m.visual, 'material', None)
        color = np.array([0.6, 0.6, 0.6, 1.0])  # fallback gray if no material found
        if mat is not None and hasattr(mat, 'baseColorFactor') and mat.baseColorFactor is not None:
            color = np.array(mat.baseColorFactor, dtype=float)
            if color.max() > 1.0:
                color = color / 255.0
        explicit_mat = pyrender.MetallicRoughnessMaterial(
            baseColorFactor=color.tolist(),
            metallicFactor=0.0,
            roughnessFactor=1.0,
            doubleSided=True,
        )
        part_mesh = pyrender.Mesh.from_trimesh(m, material=explicit_mat, smooth=False)
        primitives.extend(part_mesh.primitives)

    return pyrender.Mesh(primitives=primitives)


def mesh_extents(path):
    """Debug helper: real bounding-box size of a mesh, in whatever raw units the file uses."""
    loaded = trimesh.load(path, force='scene')
    return loaded.bounding_box.extents


def make_pose(x, y, z, roll=0.0, pitch=0.0, yaw=0.0):
    """4x4 pose matrix in the world/body frame (x-fwd, y-left, z-up)."""
    m = tft.euler_matrix(roll, pitch, yaw, axes='sxyz')
    m[:3, 3] = [x, y, z]
    return m


def build_camera_pose(cam_x, cam_y, cam_z, face_backward=False):
    """
    Camera pose (camera-to-world 4x4) for pyrender, given the camera's
    position in the world/body frame. Camera assumed level.
    pyrender/OpenGL camera looks down local -Z, with local +Y up, +X right.
    face_backward=True yaws the camera 180 deg (still level, same position)
    so it looks toward -x instead of +x - a diagnostic to check whether the
    car body is actually in the scene at all, independent of any position
    assumptions still being verified.
    """
    if face_backward:
        # 180 deg yaw about world Z: right/forward flip, up stays up.
        R = np.array([
            [0, 0, 1],
            [1, 0, 0],
            [0, 1, 0],
        ], dtype=float)
    else:
        # cam +X (right) -> world -y, cam +Y (up) -> world +z, cam +Z (backward) -> world -x
        R = np.array([
            [0, 0, -1],
            [-1, 0, 0],
            [0, 1, 0],
        ], dtype=float)
    pose = np.eye(4)
    pose[:3, :3] = R
    pose[:3, 3] = [cam_x, cam_y, cam_z]
    return pose


class RendererNode(Node):
    def __init__(self):
        # Namespace + node name chosen to match the real ZED ROS2 wrapper's
        # convention exactly: topics resolve to /zed2i/zed_node/... (the
        # wrapper documents this as "~ = /<namespace>/<node_name>/", where
        # <namespace> = camera_name param, e.g. "zed2i"). Every publisher
        # below uses a "~/..." relative name so it expands the same way.
        # NOTE: this matches the CURRENT (v5.1.0+) ZED wrapper topic naming
        # convention (~/left/color/rect/image). If the wrapper actually
        # installed on your car turns out to be an older version, the
        # convention is ~/left/image_rect_color instead - swap the topic
        # strings in __init__ below if so (grep TOPIC_ comments).
        # Namespace is "cam" (not "zed") specifically to avoid colliding with
        # a real zed_wrapper instance that might already be running (e.g.
        # for SLAM testing) and publishing its own /zed/... topics.
        #
        # Everything UNDER the namespace still matches the real ZED wrapper's
        # actual observed structure exactly (left/image_rect_color,
        # depth/image_raw, etc.) - so swapping to the real camera later is
        # just a one-line change, either:
        #   - relaunch this node with a different namespace override:
        #       --ros-args -r __ns:=/zed
        #   - or, better: write your subscriber nodes using launch-time
        #     namespace remapping/arguments rather than hardcoding "/cam/" or
        #     "/zed/" directly, so the SAME node works against either source
        #     without any code changes at all.
        super().__init__('zed_node', namespace='cam')

        # --- Parameters (fix these once you have real measured values) ---
        self.declare_parameter('image_width', 640)
        self.declare_parameter('image_height', 480)
        self.declare_parameter('hfov_radians', 1.91889)
        self.declare_parameter('publish_rate_hz', 30.0)
        self.declare_parameter('use_flat_shading', True)  # big FPS win, see render_and_publish

        self.declare_parameter('wheelbase_m', 1.53)       # ASSUMPTION - verify
        self.declare_parameter('chassis_width_m', 1.20)   # ASSUMPTION - verify
        self.declare_parameter('wheel_diameter_m', 0.505) # confirmed from wheels.urdf.xacro
        self.declare_parameter('wheel_width_m', 0.2)       # confirmed from wheels.urdf.xacro
        self.declare_parameter('wheel_spin_sign', 1.0)

        self.declare_parameter('cam_mount_x', 0.9)   # ASSUMPTION - verify (forward offset, m)
        self.declare_parameter('cam_mount_y', 0.06)  # confirmed: left eye offset from zed center
        self.declare_parameter('cam_mount_z', 0.65)  # ASSUMPTION - verify (height, m)
        self.declare_parameter('debug_face_backward', False)  # diagnostic: look at the car, not away from it

        self.declare_parameter('cone_scale', 1.0)
        self.declare_parameter('car_scale', 1.0)
        self.declare_parameter('wheel_scale', 1.0)

        w = self.get_parameter('image_width').value
        h = self.get_parameter('image_height').value
        hfov = self.get_parameter('hfov_radians').value
        self.use_flat_shading = self.get_parameter('use_flat_shading').value
        self.wheelbase = self.get_parameter('wheelbase_m').value
        self.chassis_width = self.get_parameter('chassis_width_m').value
        self.wheel_radius = self.get_parameter('wheel_diameter_m').value / 2.0
        self.wheel_width = self.get_parameter('wheel_width_m').value
        self.spin_sign = self.get_parameter('wheel_spin_sign').value
        cam_x = self.get_parameter('cam_mount_x').value
        cam_y = self.get_parameter('cam_mount_y').value
        cam_z = self.get_parameter('cam_mount_z').value
        face_backward = self.get_parameter('debug_face_backward').value
        cone_scale = self.get_parameter('cone_scale').value
        car_scale = self.get_parameter('car_scale').value
        wheel_scale = self.get_parameter('wheel_scale').value

        self.width, self.height = w, h

        # --- Load meshes ---
        self.get_logger().info('Loading meshes...')
        chassis_path = os.path.join(MESH_DIR_CAR, 'ads-dv.dae')
        wheel_left_path = os.path.join(MESH_DIR_CAR, 'wheel_left.dae')
        wheel_right_path = os.path.join(MESH_DIR_CAR, 'wheel_right.dae')

        # One-time diagnostic: print raw bounding-box sizes so scale mismatches
        # (e.g. a file authored in mm instead of m) are obvious in the log.
        for name, p in [('chassis', chassis_path), ('wheel_left', wheel_left_path)]:
            self.get_logger().info(f'{name} raw bounding box extents: {mesh_extents(p)}')
        for color, p in CONE_MESH_BY_COLOR.items():
            self.get_logger().info(f'cone[{color}] raw bounding box extents: {mesh_extents(p)}')

        chassis_mesh = load_pyrender_mesh(chassis_path, car_scale)
        wheel_left_mesh = load_pyrender_mesh(wheel_left_path, wheel_scale)
        wheel_right_mesh = load_pyrender_mesh(wheel_right_path, wheel_scale)
        self.cone_meshes = {
            color: load_pyrender_mesh(path, cone_scale)
            for color, path in CONE_MESH_BY_COLOR.items()
        }

        # --- Build the persistent scene ---
        self.scene = pyrender.Scene(ambient_light=[0.25, 0.25, 0.25], bg_color=[135, 206, 235])

        # Simple ground plane for visual context.
        ground_tm = trimesh.creation.box(extents=[80, 80, 0.02])
        ground_tm.visual.face_colors = [130, 130, 130, 255]
        ground_mesh = pyrender.Mesh.from_trimesh(ground_tm, smooth=False)
        self.scene.add(ground_mesh, pose=make_pose(0, 0, -0.02))

        self.scene.add(chassis_mesh, pose=make_pose(0, 0, 0))

        # Wheel joint fixed mount points (x, y) — z=0, spin happens live.
        half_track = (self.chassis_width - self.wheel_width) / 2.0
        self.wheel_mounts = {
            'left_front': (self.wheelbase / 2, +half_track, wheel_left_mesh),
            'right_front': (self.wheelbase / 2, -half_track, wheel_right_mesh),
            'left_rear': (-self.wheelbase / 2, +half_track, wheel_left_mesh),
            'right_rear': (-self.wheelbase / 2, -half_track, wheel_right_mesh),
        }
        self.wheel_nodes = {}
        for name, (x, y, mesh) in self.wheel_mounts.items():
            node = self.scene.add(mesh, pose=make_pose(x, y, 0, roll=math.pi / 2))
            self.wheel_nodes[name] = node
        self.wheel_angle = 0.0  # shared spin angle (all wheels same speed - no per-wheel slip modeled)

        light = pyrender.DirectionalLight(color=[1.0, 1.0, 1.0], intensity=2.0)
        # Point the light the SAME direction the camera looks (like the working
        # isolation test), so camera-facing surfaces get strong direct light
        # instead of sitting in ambient-only shadow.
        light_pose = build_camera_pose(cam_x - 1.0, 0.0, cam_z + 1.5)
        self.scene.add(light, pose=light_pose)

        cam_yfov = hfov * (h / w)
        # zfar clips rendering (and depth) at a realistic range - without this,
        # the 200m ground plane makes depth stretch out toward the horizon,
        # crushing the near-field (1-20m, where cones actually are) into an
        # indistinguishable narrow band once normalized for display.
        cam = pyrender.PerspectiveCamera(yfov=cam_yfov, aspectRatio=w / h, znear=0.05, zfar=20.0)
        # Left eye at +cam_mount_y (confirmed real offset), right eye mirrored
        # to -cam_mount_y - same baseline distance, opposite side. Same
        # camera object reused for both nodes; only the pose (position) differs.
        left_pose = build_camera_pose(cam_x, cam_y, cam_z, face_backward=face_backward)
        right_pose = build_camera_pose(cam_x, -cam_y, cam_z, face_backward=face_backward)
        self.left_cam_node = self.scene.add(cam, pose=left_pose)
        self.right_cam_node = self.scene.add(cam, pose=right_pose)
        # Focal length in pixels, matching this camera's actual projection -
        # needed to build a correct sensor_msgs/CameraInfo message.
        self.focal_px = (h / 2.0) / math.tan(cam_yfov / 2.0)

        self.renderer = pyrender.OffscreenRenderer(viewport_width=w, viewport_height=h)

        # Track dynamically-added cone nodes so we can clear them each frame.
        self.cone_nodes = []

        # --- ROS I/O ---
        self.latest_cones = []
        self.hit_cone_ids = set()
        self.current_speed = 0.0
        self.last_time = self.get_clock().now()
        self._last_wall_time = time.perf_counter()

        # Frame naming matches the real ZED wrapper's convention:
        # <camera_name>_left/right_camera_optical_frame
        self.left_optical_frame = 'cam_left_camera_optical_frame'
        self.right_optical_frame = 'cam_right_camera_optical_frame'

        self.create_subscription(ConeWithColorProbabilityArray, '/camera/cones', self.cones_cb, 10)
        self.create_subscription(
            ConeWithColorProbabilityArray,
            '/plugin/cone_collision_tracker/colliding_cones',
            self.collisions_cb,
            10,
        )
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

        # --- Topics matching the real ZED 2i ROS2 wrapper (v5.1.0+ naming) ---
        # If your actual installed zed_wrapper is pre-5.1.0, the equivalent
        # topics are: ~/left/image_rect_color and ~/depth/depth_registered
        # (drop the /color/rect/ and /depth_registered stays the same) -
        # swap the strings below if so.
        self.image_pub = self.create_publisher(Image, 'left/image_rect_color', 10)
        self.camera_info_pub = self.create_publisher(CameraInfo, 'left/camera_info', 10)
        self.right_image_pub = self.create_publisher(Image, 'right/image_rect_color', 10)
        self.right_camera_info_pub = self.create_publisher(CameraInfo, 'right/camera_info', 10)
        self.depth_pub = self.create_publisher(Image, 'depth/image_raw', 10)
        self.depth_info_pub = self.create_publisher(CameraInfo, 'depth/camera_info', 10)
        self.points_pub = self.create_publisher(PointCloud2, 'points', 10)
        # Top-level aliases also observed on the real system (/zed/image_raw,
        # /zed/camera_info) - some tools default to these instead of the
        # left/-prefixed ones, so we publish both to be safe.
        self.image_alias_pub = self.create_publisher(Image, 'image_raw', 10)
        self.camera_info_alias_pub = self.create_publisher(CameraInfo, 'camera_info', 10)

        # Precompute the static CameraInfo content once - same intrinsics for
        # left/right/depth, since our synthetic stereo pair is perfectly
        # matched (real hardware would differ slightly per-eye, but this is
        # close enough for testing).
        self.camera_info_msg = self.build_camera_info(self.left_optical_frame)
        self.right_camera_info_msg = self.build_camera_info(self.right_optical_frame)

        # Precompute per-pixel (u,v) grids once for point cloud back-projection
        # (avoid rebuilding these every frame - meshgrid is the expensive part).
        uu, vv = np.meshgrid(np.arange(w), np.arange(h))
        self._pc_uu = uu.astype(np.float32)
        self._pc_vv = vv.astype(np.float32)

        # --- Our own debug/tooling topics (not part of the ZED emulation) ---
        self.fps_pub = self.create_publisher(Float32, 'debug/fps', 10)
        self.render_time_pub = self.create_publisher(Float32, 'debug/render_time_ms', 10)
        self.cones_count_pub = self.create_publisher(Int32, 'debug/cones_in_view', 10)

        rate = self.get_parameter('publish_rate_hz').value
        self.timer = self.create_timer(1.0 / rate, self.render_and_publish)

        self.get_logger().info('3D renderer ready -> /cam/left/image_rect_color')

    def build_camera_info(self, frame_id):
        """Build a sensor_msgs/CameraInfo matching this renderer's actual projection."""
        info = CameraInfo()
        info.header.frame_id = frame_id
        info.height = self.height
        info.width = self.width
        info.distortion_model = 'plumb_bob'
        info.d = [0.0, 0.0, 0.0, 0.0, 0.0]  # perfect synthetic camera - no lens distortion
        fx = fy = self.focal_px
        cx = self.width / 2.0
        cy = self.height / 2.0
        info.k = [fx, 0.0, cx, 0.0, fy, cy, 0.0, 0.0, 1.0]
        info.r = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
        info.p = [fx, 0.0, cx, 0.0, 0.0, fy, cy, 0.0, 0.0, 0.0, 1.0, 0.0]
        return info

    def cones_cb(self, msg):
        self.latest_cones = msg.cones

    def collisions_cb(self, msg):
        self.hit_cone_ids = {c.id for c in msg.cones}

    def odom_cb(self, msg):
        self.current_speed = msg.twist.twist.linear.x

    def classify(self, cone):
        probs = {
            'blue': cone.blue_prob,
            'yellow': cone.yellow_prob,
            'orange': cone.orange_prob,
            'big_orange': cone.big_orange_prob,
        }
        return max(probs, key=probs.get)

    def update_wheel_spin(self, dt):
        angular_speed = self.current_speed / self.wheel_radius  # rad/s
        self.wheel_angle += self.spin_sign * angular_speed * dt
        for name, (x, y, _mesh) in self.wheel_mounts.items():
            # mesh's own local alignment (roll=90deg) composed with live spin about Y.
            pose = make_pose(x, y, 0, roll=math.pi / 2, pitch=self.wheel_angle)
            self.scene.set_pose(self.wheel_nodes[name], pose)

    def update_cones(self):
        for node in self.cone_nodes:
            self.scene.remove_node(node)
        self.cone_nodes = []

        for cone in self.latest_cones:
            color = self.classify(cone)
            mesh = self.cone_meshes.get(color)
            if mesh is None:
                continue
            x, y = cone.point.x, cone.point.y
            if cone.id in self.hit_cone_ids:
                # Tipped over: lying on its side, base still roughly at ground.
                pose = make_pose(x, y, 0.1, roll=math.pi / 2, yaw=0.0)
            else:
                pose = make_pose(x, y, 0.0)
            node = self.scene.add(mesh, pose=pose)
            self.cone_nodes.append(node)

    def render_and_publish(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        self.last_time = now
        if dt <= 0 or dt > 1.0:
            dt = 0.0

        self.update_wheel_spin(dt)
        self.update_cones()

        render_start = time.perf_counter()
        flags = pyrender.RenderFlags.FLAT if self.use_flat_shading else pyrender.RenderFlags.NONE

        self.scene.main_camera_node = self.left_cam_node
        color, depth = self.renderer.render(self.scene, flags=flags)

        self.scene.main_camera_node = self.right_cam_node
        right_color, _right_depth = self.renderer.render(self.scene, flags=flags)

        bgr = color[:, :, ::-1].copy()  # RGB -> BGR
        right_bgr = right_color[:, :, ::-1].copy()
        stamp = now.to_msg()

        img_msg = Image()
        img_msg.header.stamp = stamp
        img_msg.header.frame_id = self.left_optical_frame
        img_msg.height = self.height
        img_msg.width = self.width
        img_msg.encoding = 'bgr8'
        img_msg.is_bigendian = 0
        img_msg.step = self.width * 3
        img_msg.data = bgr.tobytes()
        self.image_pub.publish(img_msg)
        self.image_alias_pub.publish(img_msg)

        right_msg = Image()
        right_msg.header.stamp = stamp
        right_msg.header.frame_id = self.right_optical_frame
        right_msg.height = self.height
        right_msg.width = self.width
        right_msg.encoding = 'bgr8'
        right_msg.is_bigendian = 0
        right_msg.step = self.width * 3
        right_msg.data = right_bgr.tobytes()
        self.right_image_pub.publish(right_msg)

        # CameraInfo - same intrinsics reused for left/color and depth, since
        # depth is registered on the left image (matches real ZED wrapper).
        self.camera_info_msg.header.stamp = stamp
        self.camera_info_pub.publish(self.camera_info_msg)
        self.camera_info_alias_pub.publish(self.camera_info_msg)
        self.depth_info_pub.publish(self.camera_info_msg)
        self.right_camera_info_msg.header.stamp = stamp
        self.right_camera_info_pub.publish(self.right_camera_info_msg)

        # Depth image - pyrender already computes real metric depth (meters)
        # for free as part of rendering; we just weren't publishing it before.
        depth_msg = Image()
        depth_msg.header.stamp = stamp
        depth_msg.header.frame_id = self.left_optical_frame
        depth_msg.height = self.height
        depth_msg.width = self.width
        depth_msg.encoding = '32FC1'
        depth_msg.is_bigendian = 0
        depth_msg.step = self.width * 4
        depth_msg.data = depth.astype(np.float32).tobytes()
        self.depth_pub.publish(depth_msg)

        # Point cloud - back-project the left depth buffer through the camera
        # intrinsics into XYZ (optical-frame convention: x-right, y-down,
        # z-forward, matching the K matrix in CameraInfo), colored from the
        # left color image. Vectorized with numpy - a per-pixel Python loop
        # here would be far too slow for real-time use.
        fx = fy = self.focal_px
        cx = self.width / 2.0
        cy = self.height / 2.0
        Z = depth.astype(np.float32)
        invalid = Z <= 0.0
        X = (self._pc_uu - cx) * Z / fx
        Y = (self._pc_vv - cy) * Z / fy
        X[invalid] = np.nan
        Y[invalid] = np.nan
        Z_out = Z.copy()
        Z_out[invalid] = np.nan

        r = bgr[:, :, 2].astype(np.uint32)
        g = bgr[:, :, 1].astype(np.uint32)
        b = bgr[:, :, 0].astype(np.uint32)
        rgb_packed = ((r << 16) | (g << 8) | b).astype(np.uint32).view(np.float32)

        cloud_arr = np.dstack([X, Y, Z_out, rgb_packed]).astype(np.float32)

        cloud_msg = PointCloud2()
        cloud_msg.header.stamp = stamp
        cloud_msg.header.frame_id = self.left_optical_frame
        cloud_msg.height = self.height
        cloud_msg.width = self.width
        cloud_msg.fields = [
            PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
            PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
            PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
            PointField(name='rgb', offset=12, datatype=PointField.FLOAT32, count=1),
        ]
        cloud_msg.is_bigendian = False
        cloud_msg.point_step = 16
        cloud_msg.row_step = 16 * self.width
        cloud_msg.is_dense = False
        cloud_msg.data = cloud_arr.tobytes()
        self.points_pub.publish(cloud_msg)

        render_ms = (time.perf_counter() - render_start) * 1000.0

        # Publish FPS metrics as topics (view in Foxglove with a Plot panel)
        # instead of printing to the terminal.
        wall_now = time.perf_counter()
        real_dt = wall_now - self._last_wall_time
        self._last_wall_time = wall_now
        fps = 1.0 / real_dt if real_dt > 0 else 0.0

        self.fps_pub.publish(Float32(data=fps))
        self.render_time_pub.publish(Float32(data=render_ms))
        self.cones_count_pub.publish(Int32(data=len(self.cone_nodes)))


def main(args=None):
    rclpy.init(args=args)
    node = RendererNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.renderer.delete()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
